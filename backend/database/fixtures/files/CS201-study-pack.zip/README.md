# CS201: Data Structures

Example learning materials for the Campus demo workspace.

## Study plan
1. Review the current chapter.
2. Summarize three key ideas in your own words.
3. Complete the practical exercise and bring questions to class.
